#pragma once
#ifndef UTILS_H
#define UTILS_H

int generateRandomNumber(int min, int max);
int drawCard();
bool flipCoin();


#endif